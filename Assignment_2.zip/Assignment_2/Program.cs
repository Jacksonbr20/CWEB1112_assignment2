﻿using System;

namespace Assignment_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string N = "Noah";
            string S = "Silas";
            string C = "Chris";
            string INITIALS = "Please enter the initials of the sales rep: ";
            string INPUT_SALE = "Input sale amount?";
            double nTotal = 0;
            double sTotal = 0;
            double cTotal = 0;

            Console.WriteLine(INITIALS);
            string salesRep = Console.ReadLine();

            salesRep = salesRep.ToUpper();

            while(salesRep != "Z") {

                if (salesRep == "N") {
                    Console.WriteLine(INPUT_SALE);
                    double sale = Convert.ToDouble(Console.ReadLine());
                    nTotal += sale;
                }
                if (salesRep == "S") {
                    Console.WriteLine(INPUT_SALE);
                    double sale = Convert.ToDouble(Console.ReadLine());
                    sTotal += sale;
                }
                if (salesRep == "C") {
                    Console.WriteLine(INPUT_SALE);
                    double sale = Convert.ToDouble(Console.ReadLine());
                    cTotal += sale;
                }
                else if (salesRep != "N" && salesRep != "S" && salesRep != "C") {
                    Console.WriteLine("Try again!");
                }
                Console.WriteLine(INITIALS);
                salesRep = Console.ReadLine();
                salesRep = salesRep.ToUpper();
            }
            Console.WriteLine("Total Amount for " + N + " is : " + nTotal);
            Console.WriteLine("Total Amount for " + S + " is : " + sTotal);
            Console.WriteLine("Total Amount for " + C + " is : " + cTotal);
        }
    }
}
